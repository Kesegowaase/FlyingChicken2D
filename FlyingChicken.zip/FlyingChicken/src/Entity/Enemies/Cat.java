package Entity.Enemies;

import Entity.Animation;
import Entity.Enemy;
import TileMap.TileMap;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class Cat extends Enemy{
    
    private BufferedImage[] sprites;
    
    public Cat(TileMap tm){
        super(tm);
        moveSpeed = 0.3;
        maxSpeed = 0.3;
        
        width = 22;
        height = 32;
        cwidth = 22;
        cheight = 32;
        
        health = maxHealth = 2;
        damage = 1;
        
        //load spiretes
        try {
            BufferedImage spritesheet = ImageIO.read(getClass().getResourceAsStream("/sprites/enemies/cat-1.png"));
            sprites = new BufferedImage[2];
            for(int i = 0; i < sprites.length; i++){
                sprites[i] = spritesheet.getSubimage(i*width, 0, width, height);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        animation = new Animation();
        animation.setFrames(sprites);
        animation.setDelay(300);
        
        right = true;
        facingRight = true;
        
    }
    
    public void setFace(boolean b){
        facingRight = b;
    }
    
    public void setX(double x){
        this.x += x;
    }
    
    public void setY(double y){
        this.y += y;
    }
    
    
    public void update(){
        
        //check flinching
        if(flinching){
            long elapsed = (System.nanoTime() - flinchTimer) / 1000000;
            if(elapsed > 400){
                flinching = false;
            }
        }
        
    }
    
    public void draw(Graphics2D g){
        
        setMapPosition();
        
        super.draw(g);
    }
    
    
}
