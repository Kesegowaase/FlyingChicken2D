package Entity.Enemies;

import Entity.Animation;
import Entity.Enemy;
import TileMap.TileMap;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class Cat3 extends Enemy{

    private BufferedImage[] sprites, sprites2;
    
    public Cat3(TileMap tm){
        super(tm);
        moveSpeed = 0.3;
        maxSpeed = 0.3;
        
        width = 36;
        height = 53;
        cwidth = 36;
        cheight = 53;
        
        health = maxHealth = 8;
        damage = 1;
        
        //load spiretes
        try {
            BufferedImage spritesheet = ImageIO.read(getClass().getResourceAsStream("/sprites/enemies/cat-3.png"));
            BufferedImage spritesheet2 = ImageIO.read(getClass().getResourceAsStream("/sprites/enemies/cat-3-1.png"));
            sprites = new BufferedImage[2];
            sprites2 = new BufferedImage[2];
            for(int i = 0; i < sprites.length; i++){
                sprites[i] = spritesheet.getSubimage(i*width, 0, width, height);
                sprites2[i] = spritesheet2.getSubimage(i*width, 0, width, height);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        animation = new Animation();
        animation.setFrames(sprites);
        animation.setDelay(300);
        
        right = true;
        facingRight = true;
        
    }
    
    public void setFace(boolean b){
        facingRight = b;
    }
    
    public void setX(double x){
        this.x += x;
    }
    
    public void setY(double y){
        this.y += y;
    }
    
    public void update(){
        
        //check flinching
        if(flinching){
            long elapsed = (System.nanoTime() - flinchTimer) / 1000000;
            if(elapsed > 400){
                flinching = false;
            }
        }
        
        if(health>=5){
            animation.setFrames(sprites);
            animation.setDelay(300);
        }
        else{
            animation.setFrames(sprites2);
            animation.setDelay(300);
        }
        
    }
    
    public void draw(Graphics2D g){
        
        setMapPosition();
        
        super.draw(g);
    }
    
}
