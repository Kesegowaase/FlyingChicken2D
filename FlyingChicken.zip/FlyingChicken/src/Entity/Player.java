package Entity;

import Audio.AudioPlayer;
import TileMap.TileMap;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashMap;
import javax.imageio.ImageIO;

public class Player extends MapObject{

    //player Stuff
    private static int health = 5;
    private int maxHealth, fire, maxFire;
    public static int point = 0;
    private boolean dead, flinching;
    private long flinchTime;
    
    //fireball
    private boolean firing;
    private int fireCost, fireBallDamage;
    private ArrayList<FireBall> fireBalls;
    
    //scratch
    private boolean scratching;
    private int scratchDamage, scratchRange;
    
    
    //animations
    private ArrayList<BufferedImage[]> sprites;
    private final int[] numFrames = {
      2, 2, 2, 2, 2, 2  
    };
    
    //animation actions
    private static final int IDLE = 0;
    private static final int WALKING = 1;
    private static final int FIREBALL = 2;
    private static final int SCRATCHING = 3;
    private static final int WALKINGDOWN = 4;
    
    private HashMap<String, AudioPlayer> sfx;
    
    private double downSpeed, downMaxSpeed;
    
    public Player(TileMap tm){
        super(tm);
        
        
        width = 32;
        height = 32;
        cwidth = 20;
        cheight = 30;
        
        moveSpeed = 1;
        maxSpeed = 2;
        stopSpeed = 0.4;
        
        down = true;
        facingRight = true;
        
        maxHealth = 5;
        fire = maxFire = 1500;
        
        fireCost = 100;
        fireBallDamage = 5;
        fireBalls = new ArrayList<FireBall>();
        
        scratchDamage = 8;
        scratchRange = 40;
        
        //load sprites
        try {
            BufferedImage spriteSheet = ImageIO.read(getClass().getResourceAsStream("/sprites/player/player.png"));
            
            sprites = new ArrayList<BufferedImage[]>();
            
            for(int i = 0;i < 5; i++){
                BufferedImage[] bi = new BufferedImage[numFrames[i]];
                for(int j = 0; j< numFrames[i]; j++){
                    bi[j] = spriteSheet.getSubimage(j*width, i*height, width, height);
                }
                
                sprites.add(bi);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        animation = new Animation();
        currentAction = WALKINGDOWN ;
        animation.setFrames(sprites.get(WALKINGDOWN));
        animation.setDelay(400);
        
        sfx = new HashMap<>();
        sfx.put("fire", new AudioPlayer("/sfx/fire.mp3"));
        
        
        
    }
    public void setDownSpeed(double downSpeed){
        this.downSpeed = downSpeed;
    }
    
    public void setDownMaxSpeed(double downMaxpSpeed){
        this.downMaxSpeed = downMaxpSpeed;
    }
    
    public void setFace(boolean b){
        facingRight = b;
    }
    
    public void setX(double x){
        this.x += x;
    }
    
    public void setY(double y){
        this.y += y;
    }
    
    public void resetPoint(){
        this.point = 0;
    }
    
    public void setPoint(int point){
        this.point += point;
    }
    
    public int getPoint(){
        return point;
    }
    
    public void setHealth(int health){
        this.health = health;
    }
    
    public int getHealth(){
        return health;
    }
    public int getMaxHealth(){
        return maxHealth;
    }
    public int getFire(){
        return fire;
    }
    public int getMaxFire(){
        return maxFire;
    }
    
    public void setFiring(boolean b){
        firing = b;
    }
    
    public void setScratching(boolean b){
        scratching = b;
    }
    
    public int checkPass(ArrayList<Enemy> enemies){
        
        for(int i = 0; i< enemies.size();i++){
            Enemy e = enemies.get(i);
            if(e.getY() + height < y){
                health--;
                return i;
            }
            
        }
        return -1;
        
    }
    
    public void checkAttack(ArrayList<Enemy> enemies){
        
        
        //loop through enemies
        for(int i = 0;i< enemies.size();i++){
            Enemy e = enemies.get(i);
            
            //scratch attack
            if(scratching){
                if(facingRight){
                    if(e.getX() > x && e.getX() < x + scratchRange && e.getY() > y - height / 2 && e.getY() < y + height / 2){
                        e.hit(scratchDamage);
                    }
                }
                else{
                    if(e.getX() < x && e.getX() > x - scratchRange && e.getY() > y - height / 2 && e.getY() < y + height / 2){
                        e.hit(scratchDamage);
                    }
                }
            }
            
            //fireballs
            for(int j = 0 ;j< fireBalls.size();j++){
                if(fireBalls.get(j).intersects(e)){
                    e.hit(fireBallDamage);
                    fireBalls.get(j).setHit();
                    break;  
                }
            }
            
            // check enemy collision
            if(intersects(e)) {
                hit(e.getDamage());
            }
        }
        
    }
    
    public void hit(int damage) {
        if(flinching) return;
	health -= damage;
	if(health < 0) health = 0;
	if(health == 0) dead = true;
	flinching = true;
	flinchTime = System.nanoTime();
    }
    
    public void getNextPosition(){
        
        //movement
        if(left || right || down){
            if(left){
                dx -= moveSpeed;
                if(dx < -maxSpeed){
                    dx = -maxSpeed;
                }
            }
            if(right){
                dx += moveSpeed;
                if(dx > maxSpeed){
                    dx = maxSpeed;
                }
            }
            if(down){
                dy += downSpeed;
                if(dy > downMaxSpeed){
                    dy = downMaxSpeed;
                }
            }
        }
        else{
            if(dx > 0){
                dx -= stopSpeed;
                if(dx < 0){
                    dx = 0;
                }
            }
            if(dx < 0){
                dx += stopSpeed;
                if(dx > 0){
                    dx = 0;
                }
            }
            if(dy > 0){
                dy -= stopSpeed;
                if(dy < 0){
                    dy = 0;
                }
            }
            if(dy < 0){
                dy += stopSpeed;
                if(dy > 0){
                    dy = 0;
                }
            }
        }
        
        
    }
    
    public void update(){
        
        //update position
        getNextPosition();
        checkTileMapCollision();
        setPosition(xtemp, ytemp);
        dx = 0;
        
        //fireball attack
        fire += 5;
        if(fire > maxFire){
            fire = maxFire;
        }
        if(firing && (currentAction != FIREBALL)){
            if(fire > fireCost){
                fire -= fireCost;
                FireBall fb = new FireBall(tileMap);
                fb.setPosition(x, y);
                fireBalls.add(fb);
            }
        }
        
        //update fireball
        for(int i = 0;i < fireBalls.size();i++){
            fireBalls.get(i).update();
            if(fireBalls.get(i).shouldRemove()){
                fireBalls.remove(i);
                i--;
            }
        }
        
        
        //check done flinching
        if(flinching){
            long elapsed = (System.nanoTime() - flinchTime) / 1000000;
            if(elapsed > 1000){
                flinching = false;
            }
        }
        
        
        
        //set animation
        if(scratching || firing || left || right){
            if(scratching){
                if(currentAction != SCRATCHING){
                    currentAction = SCRATCHING;
                    animation.setFrames(sprites.get(SCRATCHING));
                    animation.setDelay(50);
                    width = 32;
                }
            }
            if(firing){
                if(currentAction != FIREBALL ){
                    sfx.get("fire").play();
                    currentAction = FIREBALL;
                    animation.setFrames(sprites.get(FIREBALL));
                    animation.setDelay(400);
                    width = 32;
                }
            }
            if(left || right){
                if(currentAction != WALKING){
                    currentAction = WALKING;
                    animation.setFrames(sprites.get(WALKING));
                    animation.setDelay(40);
                    width = 32;
                }            
            }
            
        }
        else{
            if(currentAction != WALKINGDOWN){
                currentAction = WALKINGDOWN;
                animation.setFrames(sprites.get(WALKINGDOWN));
                animation.setDelay(400);
                width = 32;
            }
        }
        
        animation.update();
        
        //set direction
        if(currentAction != SCRATCHING && currentAction != FIREBALL){
            
            if(right){
                facingRight = true;
            }
            if(left){
                facingRight = false;
            }
            
        }
    }
    
    public void draw(Graphics2D g){
        setMapPosition();
        
        //draw fireball
        for(int i = 0; i < fireBalls.size();i++){
            fireBalls.get(i).draw(g);
        }
        
        //draw player
        if(flinching){
            long elapsed = (System.nanoTime() - flinchTime) / 1000000;
            if(elapsed / 100 % 2 == 0){
                return;
            }
        }
        
        super.draw(g);
        
    }
    
    
}
