package GameState;

import Entity.Enemies.Cat;
import Entity.Enemies.Cat2;
import Entity.Enemies.Cat3;
import Entity.Enemy;
import Entity.Explosion;
import Entity.HUD;
import Entity.Player;
import Main.GamePanel;
import TileMap.TileMap;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

public class Level2State extends GameState{

    private int passed;
    private TileMap tileMap;
    private Player player;
    private ArrayList<Enemy> enemies;
    private ArrayList<Explosion> explosions;
    
    private HUD hud;
    
    
    public Level2State(GameStateManager gsm){
        this.gsm = gsm;
        init();
    }

    @Override
    public void init() {
        tileMap = new TileMap(32);
        tileMap.loadTiles("/ground/leveltile.png");
        tileMap.loadMap("/worlds/level1-1.map");
        tileMap.setPosition(0, 0);
        tileMap.setTween(1);
        
        
        player = new Player(tileMap);
        player.setPosition(195, 50);
        player.setDownSpeed(0.4);
        player.setDownMaxSpeed(0.6);
        populateEnemies();
        
        explosions = new ArrayList<Explosion>();
        
        hud = new HUD(player, 2);
        
    }
    
    private void populateEnemies(){
        enemies = new ArrayList<Enemy>();
        Cat cat;
        Cat2 cat2;
        Cat3 cat3;
        Point[] points = new Point[]{
            new Point(170, 200),
            new Point(130, 250),
            new Point(220, 300),
            new Point(150, 450),
            new Point(180, 550)
        };
        Point[] points2 = new Point[]{
            new Point(220, 200),
            new Point(120, 300),
            new Point(130, 400),
            new Point(260, 500),
        };
        
        Point[] points3 = new Point[]{
            new Point(170, 350),
            new Point(220, 550)
        };
        
        for(int i = 0;i< points.length;i++){
            cat = new Cat(tileMap);
            cat.setPosition(points[i].x, points[i].y);
            enemies.add(cat);
        }
        for(int i = 0;i<points2.length;i++){
            cat2 = new Cat2(tileMap);
            cat2.setPosition(points2[i].x, points2[i].y);
            enemies.add(cat2);
        }
        for(int i = 0;i<points3.length;i++){
            cat3 = new Cat3(tileMap);
            cat3.setPosition(points3[i].x, points3[i].y);
            enemies.add(cat3);
        }
    }

    @Override
    public void update() {
        
        //update player
        player.update();
        tileMap.setPosition(GamePanel.WIDTH / 2 - player.getX(), GamePanel.HEIGHT / 2 - player.getY());
        
        //attack enemies
        player.checkAttack(enemies);
        
        //passed enemies
        passed = player.checkPass(enemies);
        if(passed != -1){
            Enemy e = enemies.get(passed);
            enemies.remove(passed);
            explosions.add(new Explosion(e.getX(), e.getY()));
        }
        
        //game over
        if(player.getHealth() == 0){
            gsm.setState(GameStateManager.GAMEOVERSTATE);
        }
        
        //next level
        if(enemies.size() == 0){
            gsm.setState(GameStateManager.LEVEL3STATE);
        }
        
        //update all enemies
        for(int i = 0;i< enemies.size();i++){
            Enemy e = enemies.get(i);
            e.update();
            if(e.isDead()){
                enemies.remove(i);
                player.setPoint((((int)e.getWidth()/5) * ((int)e.getHeight()/5))/2);
                i--;
                explosions.add(new Explosion(e.getX(), e.getY()));
            }
        }
        
        //update explosions
        for(int i = 0;i < explosions.size();i++){
            explosions.get(i).update();
            if(explosions.get(i).shouldRemove()){
                explosions.remove(i);
                i--;
            }
        }
        
        
        
    }

    @Override
    public void draw(Graphics2D g) {

        //draw tile
        tileMap.draw(g);
        
        //draw player
        player.draw(g);
        
        //draw enemies
        for(int i = 0; i< enemies.size(); i++){
            enemies.get(i).draw(g);
        }
        
        //draw explosion
        for(int i = 0;i< explosions.size();i++){
            explosions.get(i).setMapPosition(tileMap.getX(), tileMap.getY());
            explosions.get(i).draw(g);
        }
        
        //draw hud
        hud.draw(g);
    }

    @Override
    public void keyPressed(int k) {
        if(k == KeyEvent.VK_LEFT || k == KeyEvent.VK_A){
            player.setLeft(true);
        }
        if(k == KeyEvent.VK_RIGHT || k == KeyEvent.VK_D){
            player.setRight(true);
        }
        if(k == KeyEvent.VK_UP || k == KeyEvent.VK_W){
            //player.setUp(true);
        }
        if(k == KeyEvent.VK_DOWN || k == KeyEvent.VK_S){
            //player.setDown(true);
        }
        if(k == KeyEvent.VK_CONTROL){
            player.setScratching(true);
        }
        if(k == KeyEvent.VK_SPACE){
            player.setFiring(true);
        }
    }

    @Override
    public void keyReleased(int k) {
        if(k == KeyEvent.VK_LEFT || k == KeyEvent.VK_A){
            player.setLeft(false);
        }
        if(k == KeyEvent.VK_RIGHT || k == KeyEvent.VK_D){
            player.setRight(false);
        }
        if(k == KeyEvent.VK_UP || k == KeyEvent.VK_W){
            //player.setUp(false);
        }
        if(k == KeyEvent.VK_DOWN || k == KeyEvent.VK_S){
            //player.setDown(false);
        }
        if(k == KeyEvent.VK_CONTROL){
            player.setScratching(false);
        }
        if(k == KeyEvent.VK_SPACE){
            player.setFiring(false);
        }
    }
    
}
