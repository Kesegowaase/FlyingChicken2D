package GameState;

import Entity.Enemies.Cat;
import Entity.Player;
import TileMap.Background;
import TileMap.TileMap;
import java.awt.Graphics2D;

public class IntroState extends GameState{

    private Background bg;
    private Player player;
    private TileMap tileMap;
    private Cat cat;
    
    public IntroState(GameStateManager gsm){
        this.gsm = gsm;
        init();
        try {
            bg = new Background("/ground/coop.png", 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }

    @Override
    public void init() {
        tileMap = new TileMap(32);
        player = new Player(tileMap);
        player.setPosition(266, 128);
        player.setFace(false);
        cat = new Cat(tileMap);
        cat.setPosition(320, 235);
        cat.setFace(false);
    }

    @Override
    public void update() {
        if(player.getX() > 200 && player.getY() < 280){
            player.setX(-0.9);
            player.setY(1.5);
            cat.setX(-1.2);
        }
        else{
            player.setX(-1.5);
            cat.setX(-1.2);
        }
        
        if(player.getX() == -32){
            gsm.setState(GameStateManager.LEVEL1STATE);
        }
         
    }

    @Override
    public void draw(Graphics2D g) {
        //draw bg
        bg.draw(g);
        
        //draw player
        player.draw(g);
        
        
        //draw cat
        cat.draw(g);
    }

    @Override
    public void keyPressed(int k) {
        
    }

    @Override
    public void keyReleased(int k) {
        
    }
    
}
