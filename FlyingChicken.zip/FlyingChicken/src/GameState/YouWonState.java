package GameState;

import Entity.Player;
import TileMap.Background;
import TileMap.TileMap;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;

public class YouWonState extends GameState{

    private Background bg;
    private Background bb1;
    private Background blackto10;
    private Background blackto100;
    private Background blackto1000;
    
    private int currentChoice = 0;
    private String[] options = {
        "Play Again",
        "        Quit"
    };
    
    private Player player;
    private TileMap tileMap;
    
    private Font titleFont;
    private Font font;
    private Font f;
    private Font title;
    
    public YouWonState(GameStateManager gsm){
        this.gsm = gsm;
        tileMap = new TileMap(32);
        player = new Player(tileMap);
        try {
            bb1 = new Background("/ground/blackblock4.png", 0);
            blackto10 = new Background("/ground/blackblock1.png", 0);
            blackto100 = new Background("/ground/blackblock2.png", 0);
            blackto1000 = new Background("/ground/blackblock3.png", 0);
            
            bg = new Background("/ground/coop2.png", 0);
            
            title = Font.createFont(Font.TRUETYPE_FONT, getClass().getResourceAsStream("/font/font.TTF")).deriveFont(Font.PLAIN, 28);
            titleFont = title;
            f = Font.createFont(Font.TRUETYPE_FONT, getClass().getResourceAsStream("/font/font.TTF")).deriveFont(Font.PLAIN, 20);
            font = f;
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void init() {
        
    }

    @Override
    public void update() {
        bg.update();
    }

    @Override
    public void draw(Graphics2D g) {
        //drag bg
        bg.draw(g);
        
        bb1.draw(g, 134, 77);
        if(player.getPoint() < 10)
            blackto10.draw(g, 100, 137);
        if(player.getPoint() < 100 && player.getPoint() >= 10)
            blackto100.draw(g, 100, 137);
        if(player.getPoint() < 1000 && player.getPoint() >= 100)
            blackto1000.draw(g, 93, 137);
        
        //draw options
        g.setFont(font);
        for(int i = 0; i < options.length; i++){
            if(i == currentChoice){
                g.setColor(Color.WHITE);
            }
            else{
                g.setColor(Color.BLACK);
            }
            g.drawString(options[i], 140, 200 + i * 20);
        }
        
        //draw title
        g.setColor(Color.white);
        g.setFont(titleFont);
        g.drawString("You Won", 143, 100);
        
        if(player.getPoint() < 10)
            g.drawString("Your Point " + player.getPoint(), 105, 160);
        if(player.getPoint() < 100 && player.getPoint() >= 10)
            g.drawString("Your Point " + player.getPoint(), 105, 160);
        if(player.getPoint() < 1000 && player.getPoint() >= 100)
            g.drawString("Your Point " + player.getPoint(), 98, 160);
    }
    
    private void select(){
        if(currentChoice == 0){
            player.resetPoint();
            player.setHealth(player.getMaxHealth());
            gsm.setState(GameStateManager.MENUSTATE);
        }
        if(currentChoice == 1){
            System.exit(0);
        }
    }

    @Override
    public void keyPressed(int k) {
        if(k == KeyEvent.VK_ENTER){
            select();
        }
        if(k == KeyEvent.VK_UP || k == KeyEvent.VK_W){
            currentChoice--;
            if(currentChoice == -1){
                currentChoice = options.length - 1;
            }
        }
        if(k == KeyEvent.VK_DOWN || k == KeyEvent.VK_S){
            currentChoice++;
            if(currentChoice == options.length){
                currentChoice = 0;
            }
        }
    }

    @Override
    public void keyReleased(int k) {
        
    }
    
}
